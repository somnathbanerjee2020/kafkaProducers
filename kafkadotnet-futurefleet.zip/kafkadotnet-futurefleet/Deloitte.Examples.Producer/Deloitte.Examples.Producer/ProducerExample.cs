﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Confluent.Kafka;
using Confluent.Kafka.Serialization;

namespace Deloitte.Examples.Producer
{
    public class ProducerExample
    {

        private const int NUM_MSGS_TO_SEND = 20;

        public static int Main(string[] args)
        {
            if (args.Length != 3)
            {
                Console.Error.WriteLine("usage: command <topic> <input_file> <properties_file>");
                return 1;
            }

            string topicName = args[0];
            string inputFilePath = args[1];
            string propFilePath = args[2];

            // Configure the Producer
            var configProperties = ReadIniFile(propFilePath);

            Console.WriteLine("Opening Kafka producer connection");

            try
            {
                using (var producer = new Producer<Null, string>(configProperties, null, new StringSerializer(Encoding.UTF8)))
                {
                    producer.OnError += (sender, err) => Console.WriteLine($"producer error: {err.Reason}");
                    producer.OnLog += (sender, log) => Console.WriteLine($"producer log: {log.Message}");

                    var msg = ReadFile(inputFilePath, Encoding.Default);
                    for (int x = 1; x < NUM_MSGS_TO_SEND; x++)
                    {
                        var task = producer.ProduceAsync(topicName, null, msg)
                        .ContinueWith(result =>
                        {
                            var resultMsg = result.Result;
                            if (resultMsg.Error.Code != ErrorCode.NoError)
                            {
                                Console.WriteLine($"failed to deliver message: {resultMsg.Error.Reason}");
                            }
                            else
                            {
                                Console.WriteLine($"delivered to: {result.Result.TopicPartitionOffset}");
                            }
                        });
                    }
                    producer.Flush(TimeSpan.FromSeconds(10));
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine(e.ToString());
                Console.Error.WriteLine(e.StackTrace.ToString());
                return 1;
            }

            return 0;
        }

        /// <summary>
        /// Reads a file into a string.
        /// </summary>
        /// <param name="path">Path to the file.</param>
        /// <param name="encoding">The text encoding.</param>
        /// <returns></returns>
        private static String ReadFile(string path, System.Text.Encoding encoding)
        {
            byte[] encoded = System.IO.File.ReadAllBytes(path);
            return encoding.GetString(encoded);
        }

        /// <summary>
        /// Read in an INI file. 
        /// </summary>
        /// <param name="path">Path to file.</param>
        /// <returns>Dictionary of key value pairs.</returns>
        private static Dictionary<string, object> ReadIniFile(string path)
        {
            var data = new Dictionary<string, object>();

            foreach (var row in System.IO.File.ReadAllLines(path))
            {
                data.Add(row.Split('=')[0], string.Join("=", row.Split('=').Skip(1).ToArray()));
            }

            return data;
        }  
    }
}
