/*
 * Copyright 2015 Confluent Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package io.confluent.examples.producer;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.ProducerConfig;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Properties;

import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProducerExample {
	final private static Logger logger = LoggerFactory.getLogger(ProducerExample.class);

	final private static int NUM_MSGS_TO_SEND = 20;

	public static void main(String[] args) {

		if (args.length != 2) {
			System.err.println("usage: command <topic> <input_file>");
			System.exit(1);
		}

		String topicName = args[0];
		String inputFilePath = args[1];

		String propFile = System.getProperty("producer.properties", "None");
		Properties props = new Properties();
		try {
			props.load(new FileInputStream(propFile));
		} catch (IOException e) {
			logger.error("Failed to open properties file: " +  propFile);
			e.printStackTrace();
			System.exit(1);
		}

		// Configure the Producer
		Properties configProperties = new Properties();

		// bootstrap.servers
		configProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
				props.getProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG));
		// linger.ms
		configProperties.put(ProducerConfig.LINGER_MS_CONFIG,
				props.getProperty(ProducerConfig.LINGER_MS_CONFIG));
		// retries
		configProperties.put(CommonClientConfigs.RETRIES_CONFIG,
				props.getProperty(CommonClientConfigs.RETRIES_CONFIG));
        // request.timeout.ms
        configProperties.put(CommonClientConfigs.REQUEST_TIMEOUT_MS_CONFIG,
                props.getProperty(CommonClientConfigs.REQUEST_TIMEOUT_MS_CONFIG));
		// client.id
		configProperties.put(CommonClientConfigs.CLIENT_ID_CONFIG,
				props.getProperty(CommonClientConfigs.CLIENT_ID_CONFIG));
		// key.serializer
		configProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
				props.getProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG));
		// value.serializer
		configProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
				props.getProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG));

		// TLS settings
		// security.protocol
		configProperties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG,
				props.getProperty(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG));
		// ssl.truststore.location
		configProperties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
				props.getProperty(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG));
		// ssl.truststore.password
		configProperties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
				props.getProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG));
		// ssl.keystore.location
		configProperties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
				props.getProperty(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG));
		// ssl.keystore.password
		configProperties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG,
				props.getProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG));
		// ssl.key.password
		configProperties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG,
				props.getProperty(SslConfigs.SSL_KEY_PASSWORD_CONFIG));

		logger.info("Opening Kafka producer connection");
		try (Producer<String, String> producer = new KafkaProducer<>(configProperties)) {
			String msg = ProducerExample.readFile(inputFilePath, Charset.defaultCharset());
			ProducerRecord<String, String> prodRec = new ProducerRecord<>(topicName, msg);
			for (int x = 1; x < NUM_MSGS_TO_SEND; x++) {
			    logger.debug("sent message number " + x);
				producer.send(prodRec);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static String readFile(String path, Charset encoding) throws IOException {
		byte[] encoded = Files.readAllBytes(Paths.get(path));
		return new String(encoded, encoding);
	}
}
