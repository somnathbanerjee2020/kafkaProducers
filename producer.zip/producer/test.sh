#!/bin/bash
set -x
KRBUSER=${1:-"default"}
JAR_FILE="target/producer-example-2.0.1.jar"
JAAS_FILE="${KRBUSER}.jaas.conf"
CLASSPATH="$CLASSPATH:./log4j.properties:$JAR_FILE"
TEST_CLASS="io.confluent.examples.producer.ProducerExample"

#java -jar ${JAR_FILE} -Djava.security.auth.login.config=${JAAS_FILE} -Dexec.mainClass="${TEST_CLASS}"

mvn exec:java -Djava.security.auth.login.config=default.jaas.conf -Dexec.mainClass="io.confluent.examples.producer.ProducerExample" -Dlog4j.configuration=file:src/main/resources/log4j.properties
