# Kafka example producer

This is extended from the Confluent sample to include example properties
for connecting to Toll.

## Compile

We use the Shade plugin to Maven so we can create an executable fat jar.

```
mvn clean package shade:shade
```

## Run

Replace the topic name and input file with the correct values for your 
connection to Toll. The properties file path is expected to be passed as a JVM
runtime property.

```
java -D"producer.properties=conf/geobox.properties" -jar target/producer-example-2.1.0.jar geobox-raw-topic-external input/geobox.json
```

## Debugging

In order to see full debug replace `INFO` with `DEBUG` on this line
in `src/resources/log4j.properties`:

```
log4j.rootLogger=INFO, stdout, file
```
